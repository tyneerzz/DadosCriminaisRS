
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" src="https://kryogenix.org/code/browser/sorttable/sorttable.js"></script>
    <title>Projeto</title>
</head>
<body>
    <h1>Indicadores criminais da Região Metropolitano do Rio Grande do Sul no ano de 2022</h1>
    <p>Dados de Janeiro até Agosto do ano de 2022.</p>
    <h2>Objetivos:</h2>
    <p># Mostrar com mais facilidade, para os usuários, os dados de ocorrências de crimes que ocorreram na Região Metropolitana do Rio Grande do Sul no período;</p>
    <p># Constatar os municípios da Região Metropolitana do Rio Grande do Sul com maiores e menores números de crimes no período. </p>
    <h2>Procedimento:</h2>
    <p>Através da base de dados do govero, analizamos os dados das 36 cidades que fazem parte da Região Metropolitan e montamos o banco de dados.</p>
    <p>Ordene a tabela como preferir.</p>
    

<table border=2 class="sortable">
    
    <tr>
    <th>Município</th>
    <th>Homicídio</th>
    <th>Furto</th>
    <th>Roubo</th>
    <th>Estelionato</th>
    <th>Tráfico</th>
    </tr>

    <?php include("BD.php");

    $query = "SELECT * FROM dados";
    $resulta = $mysqli->query($query);

    if ($resulta->num_rows > 0){

        while ( $row = $resulta->fetch_assoc()){            

            echo '<tr>';
            echo '<td>'. $row['municipios'] .'</td>';
            echo '<td>'. $row['homicidio'] .'</td>';
            echo '<td>'. $row['furto'] .'</td>';
            echo '<td>'. $row['roubo'] .'</td>';
            echo '<td>'. $row['estelionato'] .'</td>';
            echo '<td>'. $row['tráfico'] .'</td>';
            echo '</tr>';
        }
    }
    ?>
</table>
    <h2>Conclusões:</h2>
    <p># Analisando os dados podemos perceber que quanto mais perto de Porto Alegre maior são os índices de criminalidade;</p>
    <p># O índice de criminalidade também está ligado muito ao número de habitantes do município, pelo padrão, quanto maior o número de habitantes, maior é o número de criminalidade. </p>
    <p>Site do governo do Rio Grande do Sul com a base de dados utilizada(arquivo referente ao ano de 2022):
    <a href="https://ssp.rs.gov.br/indicadores-criminais">Acesse aqui</a></p>
    
</body>
</html>