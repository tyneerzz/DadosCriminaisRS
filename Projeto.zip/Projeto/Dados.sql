SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE table `Dados`(
    `municipios` varchar(40) not null,
    `homicidio` int,
    `furto` int,
    `roubo` int,
    `estelionato` int,
    `tráfico` int
)ENGINE=inooDB DEFAULT CHARSET=utf8mb4;
    
ALTER TABLE `Dados`
ADD PRIMARY KEY (`municipios`);

INSERT INTO `Dados` (`municipios`, `homicidio`, `furto`, `roubo`, `estelionato`, `tráfico` )
VALUES ('ALVORADA', 47, 999, 1191, 976, 307);

INSERT INTO `Dados`
VALUES ('ARARICÁ', 0, 33, 7, 19, 2);

INSERT INTO `Dados`
VALUES ('ARROIO DOS RATOS',	0, 76, 9 , 43, 30);

INSERT INTO `Dados`
VALUES ('CACHOEIRINHA',	5, 898, 535 , 890, 141);

INSERT INTO `Dados`
VALUES ('CAMPO BOM', 2, 444, 71 , 377, 30);

INSERT INTO `Dados`
VALUES ('CANOAS', 50, 2541, 1379 , 2876, 514);

INSERT INTO `Dados`
VALUES ('CAPELA DE SANTANA', 5 , 38, 0 , 28, 6);

INSERT INTO `Dados`
VALUES ('CHARQUEADAS', 0, 136, 4 , 88, 191);

INSERT INTO `Dados`
VALUES ('DOIS IRMÃOS', 0, 108, 16 , 184, 9);

INSERT INTO `Dados`
VALUES ('ELDORADO DO SUL', 8, 236, 47 , 241, 93);

INSERT INTO `Dados`
VALUES ('ESTÂNCIA VELHA', 3, 269, 56 , 40, 5);

INSERT INTO `Dados`
VALUES ('ESTEIO', 6, 756, 209 , 560, 89);

INSERT INTO `Dados`
VALUES ('GLORINHA',	0, 37, 8 , 31, 2);

INSERT INTO `Dados`
VALUES ('GRAVATAÍ',	20, 1550, 834 , 1696, 199);

INSERT INTO `Dados`
VALUES ('GUAÍBA', 2, 470, 144 , 330, 87);

INSERT INTO `Dados`
VALUES ('IGREJINHA', 4, 235, 12 , 101, 14);

INSERT INTO `Dados`
VALUES ('IVOTI',	1, 72, 7 , 93, 2);

INSERT INTO `Dados`
VALUES ('MONTENEGRO',	0, 327, 42 , 322, 108);

INSERT INTO `Dados`
VALUES ('NOVA HARTZ',	2, 94, 4 , 91, 6);

INSERT INTO `Dados`
VALUES ('NOVA SANTA RITA',	4, 158, 24 , 209, 19);

INSERT INTO `Dados`
VALUES ('NOVA HAMBURGO',	20, 2229, 627 , 1206, 227);

INSERT INTO `Dados`
VALUES ('PAROBÉ',	4, 235, 37 , 255, 48);

INSERT INTO `Dados`
VALUES ('PORTÃO',	1, 196, 34 , 213, 22);

INSERT INTO `Dados`
VALUES ('PORTO ALEGRE',	196, 18045, 10790 , 12752, 2026);

INSERT INTO `Dados`
VALUES ('ROLANTE',	1, 76, 12 , 139, 18);

INSERT INTO `Dados`
VALUES ('SANTO ANTÔNIO DA PATRULHA',	1, 269, 22 , 157, 42);

INSERT INTO `Dados`
VALUES ('SÃO JERÔNIMO',	1, 158, 13 , 85, 24);

INSERT INTO `Dados`
VALUES ('SÃO LEOPOLDO',	20, 2553, 783 , 1192, 301);

INSERT INTO `Dados`
VALUES ('SÃO SEBATIÃO DO CAÍ',	0, 154, 20 , 152, 33);

INSERT INTO `Dados`
VALUES ('SAPIRANGA', 1, 495, 69 , 317, 56);

INSERT INTO `Dados`
VALUES ('SAPUCAIA DO SUL',	12, 1114, 480 , 582, 137);

INSERT INTO `Dados`
VALUES ('TAQUARA',	8, 443, 53 , 142, 39);

INSERT INTO `Dados`
VALUES ('TRIUNFO',	3, 169, 11 , 120, 28);

INSERT INTO `Dados`
VALUES ('VIAMÃO',	30, 1360, 1370 , 1236, 299);