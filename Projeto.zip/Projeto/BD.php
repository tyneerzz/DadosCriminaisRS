<?php
$mysqli = new mysqli("localhost", "root", "", "dados");

if ($mysqli->connect_errno) {
    echo "Falhou em conectar ao MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


