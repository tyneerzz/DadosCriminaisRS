
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" src="https://kryogenix.org/code/browser/sorttable/sorttable.js"></script>
    <title>Projeto</title>
</head>
<body>
    <h1>Indicadores criminais da Região Metropolitana do Rio Grande do Sul no ano de 2022</h1>
    <p>Dados de Janeiro até Agosto do ano de 2022.</p>
    <h2>Objetivos:</h2>
    <p># Mostrar com mais facilidade, para os usuários, os dados de ocorrências de crimes que ocorreram na Região Metropolitana do Rio Grande do Sul no período;</p>
    <p># Constatar os municípios da Região Metropolitana do Rio Grande do Sul com maiores e menores números de crimes no período. </p>
    <p># Ter o conhecimento dos dados criminais das cidades mais perigosas de se viver e também visitar na Região Metropolitana do Rio Grande do Sul. </p>   
    <h2>Procedimentos metodológicos:</h2>
    <p>Através da base de dados do governo, analizamos os dados das 34 cidades que fazem parte da Região Metropolitana e montamos o banco de dados
         com o número de ocorrências de homicídio, furto, roubo, estelionato e tráfico. Com o banco de dados montado, fizemos a página web através da linguangem de programação PHP, juntamente com HTML e CSS.</p>
    <p>Ordene a tabela como preferir.</p>
    

<table border=2 class="sortable">
    
    <tr>
    <th>Município</th>
    <th>Homicídio</th>
    <th>Furto</th>
    <th>Roubo</th>
    <th>Estelionato</th>
    <th>Tráfico</th>
    </tr>

    <?php include("BD.php");

    $query = "SELECT * FROM dados";
    $resulta = $mysqli->query($query);

    if ($resulta->num_rows > 0){

        while ( $row = $resulta->fetch_assoc()){            

            echo '<tr>';
            echo '<td>'. $row['municipios'] .'</td>';
            echo '<td>'. $row['homicidio'] .'</td>';
            echo '<td>'. $row['furto'] .'</td>';
            echo '<td>'. $row['roubo'] .'</td>';
            echo '<td>'. $row['estelionato'] .'</td>';
            echo '<td>'. $row['tráfico'] .'</td>';
            echo '</tr>';
        }
    }
    ?>
</table>
<div class="figure"> 
    <p>Para uma melhor análise dos dados criminais, veja o mapa abaixo para saber a localização dos munícipios.</p>
    <img src="Imagem/Mapa.jpg"
        alt="Mapa da Região Metropolitana do Rio Grande do Sul"
        
        title="Mapa da Região Metropolitana do Rio Grande do Sul">
    
    
</div>
<div class="figure2"> 
    <p>Para ajudar na análise dos dados criminais, veja tabela abaixo para saber a população dos munícipios.</p>
    <img src="Imagem/Populacao2.png"
        alt="Tabela da população da Região Metropolitana do Rio Grande do Sul"
        
        title="Tabela da população da Região Metropolitana do Rio Grande do Sul">
</div>
    <h2>Conclusões:</h2>
    <p># Analisando os dados podemos perceber que quanto mais perto de Porto Alegre maior são os índices de criminalidade;</p>
    <p># O índice de criminalidade também está ligado muito ao número de habitantes do município, pelo padrão, quanto maior o número de habitantes, maior é o número de criminalidade. </p>
    <p># Analisando a tabela, se percebe que na maioria dos municípios o maior número de ocorrências de crimes é o furto ou o estelionato, com exceção das cidades de Alvorada e Charqueadas que é roubo e o tráfico, respectivamente.</p>
    <p># As cidades mais seguras para se viver na Região Metropolitana do Rio Grande do Sul são as cidades que apresentam os menores números de população</p>
    
    <h2>Fonte dos dados:</h2>
    <p>- Site do governo do Rio Grande do Sul com a base de dados de ocorrências de crimes utilizada(arquivo referente ao ano de 2022):
    <a href="https://ssp.rs.gov.br/indicadores-criminais">Acesse aqui</a></p>

    <p>- Site do governo do Rio Grande do Sul com a tabela da população das cidades utilizada:
    <a href="https://atlassocioeconomico.rs.gov.br/regiao-metropolitana-de-porto-alegre-rmpa">Acesse aqui</a></p>
    
</body>
</html>